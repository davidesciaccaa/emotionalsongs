/**@author Davide Sciacca, matricola nr. 749913, sede VARESE. Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;
import java.io.File;
import java.util.LinkedList;

import prog.io.ConsoleInputManager;

public class EmotionalSongs{

    /**main da cui partirà l'app*/
    public static void main(String[] args){
        boolean rimaniNellAppNonLoggato = true;
        boolean rimaniNellAppLoggato = false;
        String nomePInserita = " ";
        ConsoleInputManager in = new ConsoleInputManager();
        System.out.println("Questo e' un sistema di annotazione di emozioni percepite durante");
        System.out.println("l'ascolto di brani musicali.");
        System.out.println();
        System.out.println();


        while(rimaniNellAppNonLoggato || rimaniNellAppLoggato) {
        System.out.println("OPERAZIONI DISPONIBILI:");
        System.out.println("1) Login");
        System.out.println("2) Signup");
        System.out.println("3) Visualizza le emozioni inserite dagli utenti");
        System.out.println("4) Ricerca brano");
        System.out.println("5) Esci dall'app");

        int x ;
        do{
            x = in.readInt("Scegliere una operazione (inserire solo il codice): ");
        }while(!(x == 1) && !(x == 2) && !(x == 3) && !(x == 4) && !(x == 5));
        System.out.println();

        switch(x){
            case 1:
                System.out.println("LOGIN:");
                Login l = new Login();
                boolean check = Login.returnVal();
                if(check){
                  rimaniNellAppLoggato = true;
                  rimaniNellAppNonLoggato = false;
                  while(rimaniNellAppLoggato){

                  System.out.println();
                  System.out.println("OPERAZIONI DISPONIBILI:");
                  System.out.println("1) Visualizza le emozioni inserite dagli utenti");
                  System.out.println("2) Registra playlist"); //case2 non ha break
                  System.out.println("3) Inserisci emozioni");
                  System.out.println("4) Ricerca brano");
                  System.out.println("5) Esci dall'app");

                  int y;
                  do{
                      y = in.readInt("Scegliere una operazione (inserire solo il codice): ");
                  }while(!(y == 1) && !(y == 2) && !(y == 3) && !(y == 4) && !(y == 5));

                  switch(y){
                    case 1:
                        System.out.println("RICERCA DEL BRANO:");
                        int n;
                        do{
                            n = in.readInt("Inserire 1 per eseguire la ricerca per titolo oppure 2 per la ricerca per autore e anno di pubblicazione: ");
                        }while(!(n == 1) && !(n == 2));
                        //ricerca del brano
                        LinkedList<String> lista = new LinkedList<String>();
                        lista = CercaBrano.cercaBranoMusicale(n, in);

                        //selezionamento del brano
                        CercaBrano c = new CercaBrano();
                        String brano = c.SceltaBrano(lista, in);

                        if(!brano.equals(" ")){
                            int indice = brano.indexOf(";");
                            String titolo = brano.substring(0, indice);
                            String autore = brano.substring(indice + 1);

                        	File file = new File("./../data/Emozioni.dati.txt");
                            Visualizza v = new Visualizza(file.getName());
                            v.visualizzaEmozioneBrano(titolo, autore);
                        }

                        System.out.println("Vuoi chiudere l'app?");
                        if(in.readSiNo()){
                          System.out.println("Chiusura dell'app");
                          rimaniNellAppNonLoggato=false;
                          rimaniNellAppLoggato=false;
                        }

                        break;

                    case 2:
                        System.out.println();
                        System.out.println("CREAZIONE PLAYLIST:");
                        Playlist p = new Playlist();
                        String nomePlaylist;
                        boolean b;
                        do{
                            nomePlaylist = in.readLine("Inserire il nome del playlist da creare: ");
                            b = p.checkNomePlaylist(nomePlaylist);
                            if (b == true){
                                System.out.println("Nome playlist gia usato. Scegliere un'altro");
                                boolean continua = in.readSiNo("Vuoi visualizzare i nomi di tutte le playlist registrate (s = Si, n = No)?");
                                if(continua == true){
                                    Playlist.ReadAllPlaylists();
                                }
                            }
                        }while(b == true);

                        nomePInserita = nomePlaylist;
                        p.RegistraPlaylist(nomePlaylist, in);
                        System.out.println("Vuoi chiudere l'app?");
                        if(in.readSiNo()){
                          System.out.println("Chiusura dell'app");
                          rimaniNellAppNonLoggato=false;
                          rimaniNellAppLoggato=false;
                        }
                        break;



                    case 3:
                        System.out.println();
                        System.out.println();
                        System.out.println("INSERIMENTO EMOZIONI:");
                        LinkedList<String> list = new LinkedList<String>();
                        String nomePdaInserire ;
                        Playlist pl = new Playlist();

                        if(nomePInserita == " "){ // non si e arrivati qua da case2, quindi bisogna chiedere di nuovo il nome della playlist
                            String nomePlaylist2;
                            boolean bool;
                            do{
                                nomePlaylist2 = in.readLine("Inserire il nome dela playlist da cercare: ");
                                bool = pl.checkNomePlaylist(nomePlaylist2);

                                if (bool == false){ //nome gia usato
                                    System.out.println();
                                    System.out.println("La playlist non esiste.");
                                    boolean continua = in.readSiNo("Vuoi visualizzare i nomi di tutte le playlist registrate (s = Si, n = No)?");
                                    if(continua == true){
                                        Playlist.ReadAllPlaylists();
                                    }
                                }
                            }while(bool == false);

                            nomePdaInserire = nomePlaylist2;

                        }else{
                            nomePdaInserire = nomePInserita;
                        }

                        list = pl.LetturaTitoloAutorePlaylist(nomePdaInserire); //contiene "titolo;autore"

                        for(int j = 0; j < list.size(); j = j + 1){
                            String s = list.get(j);
                            int ind = s.indexOf(";");
                            String tit = s.substring(0, ind);
                            String aut = s.substring(ind + 1);

                            System.out.println("Inserire le emozioni provate dall'ascolto di:");
                            System.out.println("Brano: " + tit);
                            System.out.println("Autore: " + aut);
                            System.out.println();

                            Inserimento i = new Inserimento(tit, aut);
                            i.InserisciEmozioniBrano(in);

                        }
                        System.out.println("Vuoi chiudere l'app?");
                        if(in.readSiNo()){
                          System.out.println("Chiusura dell'app");
                          rimaniNellAppNonLoggato=false;
                          rimaniNellAppLoggato=false;
                        }
                        break;

                    case 4:
                        System.out.println();
                        System.out.println();
                        System.out.println("RICERCA DI UN BRANO:");
                        int num;
                        do{
                          num = in.readInt("Inserire 1 per eseguire la ricerca per titolo oppure 2 per la ricerca per autore + anno di pubblicazione: ");
                        }while(!(num == 1) && !(num == 2));
                        //ricerca del brano
                        LinkedList<String> listaBrani = new LinkedList<String>();
                        listaBrani = CercaBrano.cercaBranoMusicale(num, in);
                        for (String song: listaBrani) {
                          System.out.println(song);
                        }
                        System.out.println("Vuoi chiudere l'app?");
                        if(in.readSiNo()){
                          System.out.println("Chiusura dell'app");
                          rimaniNellAppNonLoggato=false;
                          rimaniNellAppLoggato=false;
                        }
                        break;
                    case 5:
                        System.out.println();
                        System.out.println();
                        System.out.println("Chiusura dell'app");
                        rimaniNellAppNonLoggato=false;
                        rimaniNellAppLoggato=false;
                        break;
                }
               }
              }

                break;
            case 2:
                System.out.println();
                System.out.println("SIGNUP/REGISTRAZIONE:");
                Signup s = new Signup();
                System.out.println("Vuoi chiudere l'app?");
                if(in.readSiNo()){
                  System.out.println("Chiusura dell'app");
                  rimaniNellAppNonLoggato=false;
                  rimaniNellAppLoggato=false;
                }
                break;
            case 3:
                System.out.println("RICERCA DEL BRANO:");
                int n;
                do{
                    n = in.readInt("Inserire 1 per eseguire la ricerca per titolo oppure 2 per la ricerca per autore + anno di pubblicazione: ");
                }while(!(n == 1) && !(n == 2));
                //ricerca del brano
                LinkedList<String> lista = new LinkedList<String>();
                lista = CercaBrano.cercaBranoMusicale(n, in);

                //selezionamento del brano
                CercaBrano c = new CercaBrano();
                String brano = c.SceltaBrano(lista, in);

                if(!brano.equals(" ")){
                    int indice = brano.indexOf(";");
                    String titolo = brano.substring(0, indice);
                    String autore = brano.substring(indice + 1);
                    System.out.println();
                    File file = new File("./../data/Emozioni.dati.txt");
                    Visualizza v = new Visualizza(file.getName());
                    v.visualizzaEmozioneBrano(titolo, autore);
                }
                System.out.println("Vuoi chiudere l'app?");
                if(in.readSiNo()){
                  System.out.println("Chiusura dell'app");
                  rimaniNellAppNonLoggato=false;
                  rimaniNellAppLoggato=false;
                }
                break;
            case 4:
                System.out.println("RICERCA DI UN BRANO:");
                int num;
                do{
                  num = in.readInt("Inserire 1 per eseguire la ricerca per titolo oppure 2 per la ricerca per autore + anno di pubblicazione: ");
                }while(!(num == 1) && !(num == 2));
                //ricerca del brano
                LinkedList<String> listaBrani = new LinkedList<String>();
                listaBrani = CercaBrano.cercaBranoMusicale(num, in);
                for (String song: listaBrani) {
                  System.out.println(song);
                }
                System.out.println("Vuoi chiudere l'app?");
                if(in.readSiNo()){
                  System.out.println("Chiusura dell'app");
                  rimaniNellAppNonLoggato=false;
                  rimaniNellAppLoggato=false;
                }
                break;
            case 5:
                System.out.println();
                System.out.println();
                System.out.println("Chiusura dell'app");
                rimaniNellAppNonLoggato=false;
                rimaniNellAppLoggato=false;
                break;
        }
      }
    }

}
