/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/
package emotionalsongs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Consente di registrare delle informazioni messe in input dall'utente su un
 * file: UtentiRegistrati.dati(file .txt o .csv) grazie al quale sara' possibile
 * effettuare il login.
 *
 * @author Davide Sciacca
 * @version Java 17
 */
public class Signup {
	/**
	 * e' fondamentale per chiedere dati in input all'utente che si sta registrando
	 */
	public Scanner scan = new Scanner(System.in);
	/** mi permette di salvare il nome inserito dall'utente */
	public String nome;
	/** mi permette di salvare il cognome inserito dall'utente */
	public String cognome;
	/** mi permette di salvare il codice fiscale inserito dall'utente */
	public String codiceFiscale;
	/** mi permette di salvare la via di residenza dell'utente */
	public String nomeVia;
	/**
	 * mi permette di salvare il numero civico della via di residenza dell'utente,
	 * potrebbe contenere anche lettere un numero civico, quindi l'ho messo come
	 * String
	 */
	public String numCivico;
	/** mi permette di salvare il cap dell'utente */
	public int cap;
	/** mi permette di salvare il comune di residenza dell'utente */
	public String comune;
	/** mi permette di salvare la provincia dell'utente */
	public String provincia;
	/** il format dell'indirizzo fisico: nomeVia+numCivico+cap+comune+provincia */
	public String indirizzoFisico;
	/** mi permette di salvare l'indirizzo mail dell'utente */
	public String email;
	/** mi permette di salvare l'id dell'utente */
	public String userId;
	/** mi permette di salvare la password dell'utente */
	public String password;

	/** Costruttore per registrare un utente */
	public Signup() {
		boolean checkNomCognCodFisc = false;

		/** Controllo nome cognome e codice fiscale */
		while (checkNomCognCodFisc == false) {

			/** richiesta del nome */
			System.out.print("Inserisci il tuo nome: ");
			nome = scan.nextLine();
			while (checkString(nome.trim()) == false) {
				nome = scan.nextLine();
			}

			/** richiesta del cognome */
			System.out.print("Inserisci il tuo cognome: ");
			cognome = scan.nextLine();
			cognome = cognome.trim();
			while (checkString(cognome.trim()) == false) {
				cognome = scan.nextLine();
				cognome = cognome.trim();
			}

			/** richiesta del codice fiscale */
			System.out.print("Inserisci il tuo codice fiscale: ");
			codiceFiscale = scan.nextLine();
			/** controllo che sia un codice alfanumerico di 16 cifre */
			while (checkCodFiscale(
					codiceFiscale) == false) { /**
												 * se il codice inserito non è di 16 cifre oppure contiene solo numeri o
												 * solo lettere, chiede di inserire nuovamente il codice fiscale
												 */
				codiceFiscale = scan.nextLine();
			}

			System.out.print("Bene signor " + nome.trim() + " " + cognome.trim() + ", il suo codice fiscale e' "
					+ codiceFiscale.trim() + ". Hai inserito tutto correttamente? (si/no): ");
			String sn = scan.nextLine();
			/** si o no */
			while (sn.toLowerCase().trim().equals("si") == false && sn.toLowerCase().trim().equals("no") == false) {
				System.out.print("Puoi inserire solamente si o no: ");
				sn = scan.nextLine();
			}

			if (sn.toLowerCase().trim().equals("no") == true) {
				System.out.print("Reinserisci il tuo nome, il tuo cognome e il tuo codice fiscale correttamente. ");
			} else if (sn.toLowerCase().trim().equals("si") == true) {
				checkNomCognCodFisc = true;
			}

		}

		/**
		 * RICHIESTA DEI DATI SULLA RESIDENZA DELL'UTENTE ci sara' una verifica che
		 * l'utente abbia inserito correttamente i dati di residenza:
		 */
		boolean checkIndirizzo = false;
		while (checkIndirizzo == false) {

			/** inserimento della via dell'utente senza numero civico */
			System.out.print("Inserire il nome della tua via: ");
			nomeVia = scan.nextLine();
			while (checkVia(nomeVia) == false) {
				nomeVia = scan.nextLine();
			}

			/**
			 * Inserimento del numero civico, controllo del formato e dell'eccezione
			 * java.util.InputMismatchException
			 */
			System.out.print("Inserire il numero civico: ");
			numCivico = scan.nextLine().trim();
			while (numCivico.trim() == "") {
				System.out.print("Inserisci un numero civico: ");
				numCivico = scan.nextLine().trim();
			}

			/**
			 * inserimento del CAP, controllo del formato e dell'eccezione
			 * java.util.InputMismatchException
			 */
			System.out.print("Inserire il CAP: ");
			cap = checkInt(cap);
			// avanzo di una riga per evitare errori
			scan.nextLine();

			/** richiesta del comune in cui vive l'utente */
			System.out.print("Inserisci il comune di residenza: ");
			comune = scan.nextLine();
			while (checkString(comune.trim()) == false) {
				comune = scan.nextLine();
			}
			/** richiesta della provincia in cui vive l'utente */
			System.out.print("Inserisci la provincia: ");
			provincia = scan.nextLine();
			while (checkString(provincia) == false) {
				provincia = scan.nextLine();
			}
			/** Ora posso formare l'indirizzo fisico */
			indirizzoFisico = nomeVia + " n." + numCivico + ", " + cap + ", " + comune + ", " + provincia;
			System.out.println("Quindi abiti in: " + indirizzoFisico);
			System.out.print("Il tuo indirizzo e' corretto? Inserisci si o no: ");
			String sn = scan.nextLine();
			/** si o no */
			while (sn.toLowerCase().trim().equals("si") == false && sn.toLowerCase().trim().equals("no") == false) {
				System.out.print("Puoi inserire solamente si o no: " + "\n");
				sn = scan.nextLine();
			}
			if (sn.toLowerCase().trim().equals("no") == true) {
				System.out.print("Reinserisci i dati di residenza correttamente. " + "\n");
			} else if (sn.toLowerCase().trim().equals("si") == true) {
				checkIndirizzo = true;
			}
		}
		/** FINE RICHIESTA DEI DATI SULLA RESIDENZA DELL'UTENTE */

		/** richiesta email */
		System.out.print("Bene, ora inserisci la tua email: ");
		email = scan.nextLine();
		while (checkEmail(email) == false) {
			email = scan.nextLine();
		}

		/** richiesta nome utente */
		System.out.print("Inserisci il nome utente: ");
		userId = scan.nextLine();

		boolean checkNoDoubleUserId = false;
		boolean checkEscaUserId = true;

		while (userId.trim() == "" || checkNoDoubleUserId == false) {
			int cont = 0;

			List<String> listaUtenti = Utility.ReadFile("UtentiRegistrati.txt");
			BufferedReader in = null;

			for (String utenti : listaUtenti) {
				cont++;
				Reader inputString = new StringReader(utenti);
				in = new BufferedReader(inputString);
			}

			try {
				File file = new File("./../data/UtentiRegistrati.txt");

				BufferedReader reader = new BufferedReader(new FileReader(file.getAbsoluteFile().getAbsolutePath()));
				int i = 0;
				while (i < cont) {
					String currentLine = reader.readLine();
					String key;
					StringTokenizer st = new StringTokenizer(currentLine);
					if (st.hasMoreTokens()) {
						key = "" + st.nextToken("|");
						key = key.trim();
					}
					if (st.hasMoreTokens()) {
						key = "" + st.nextToken("|");
						key = key.trim();
						if (key.trim().equals(userId.trim())) {
							System.out
									.println("Qualche utente si e' registrato gia' con questo nome utente, riprova. ");
							checkEscaUserId = false;
						}
					}
					i++; // per avanzare di riga, quindi per visitare un possibile account successivo
							// presente in UtentiRegistrati.txt
				}
				reader.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (checkEscaUserId == true) {
				checkNoDoubleUserId = true;
			} else {
				userId = scan.nextLine();
			}
			checkEscaUserId = true;
		}

		/** richiesta pasword */
		System.out.print("Inserisci una password almeno di 8 caratteri alfanumerici: ");
		password = scan.nextLine();
		/** l'utente deve inserire una password lunga almeno 8 caratteri alfanumerici */
		while (!checkPassword(password)) {
			password = scan.nextLine();
		}

		/** stampa gli account sul file sul .txt */
		try {
			File file = new File("./../data/UtentiRegistrati.txt");
			Writer writer  = new OutputStreamWriter(new FileOutputStream(file.getAbsoluteFile().getAbsolutePath(), true), StandardCharsets.UTF_8);
			writer.append(nome + " " + cognome + " " + nomeVia + " " + numCivico + " " + cap + " " + comune + " " + provincia + " " + email + " | " + userId + " | " + password + "\n");
			writer.close();
		} catch (Exception e) {
			// genera automaticamente un catch
			e.printStackTrace();
		}
	} // fine costruttore

	/**
	 * METODO STATICO CHE CONTROLLA IL FORMAT DELLA PASSWORD: ALMENO 8 CARATTERI E CHE CONTENGA ALMENO UNA LETTERA E UN NUMERO
	 */
	private static boolean checkPassword(String psw) {
		boolean checkPsw = false;
		boolean checkPswLettera = false;
		boolean checkPswNumero = false;
		if (psw.length() < 8) {
			System.out.println("Hai inserito una password troppo corta. Riprova.");
			return false;
		} else {
			for (int i = 0; i < psw.length(); i++) {
				Character lettera = psw.trim().charAt(i);
				if (Character.isDigit(lettera)) {
					checkPswNumero = true;
				}
				if (Character.isLetter(lettera)) {
					checkPswLettera = true;
				}
			}
			if (checkPswNumero == false) {
				System.out.println("Non hai inserito nessun numero nella password. Riprova. ");
				return false;
			}
			if (checkPswLettera == false) {
				System.out.println("Non hai inserito nessuna lettera nella password. Riprova. ");
				return false;
			} else {
				return true;
			}
		}
	}

	/**
	 * Controllo il formato del cap, che sia un numero >0 e che non contenga lettere.
	 */
	private int checkInt(int x) {
		boolean correctNumber = false;
		while (!correctNumber) {
			try {
				x = scan.nextInt();
				if (x <= 0) {
					System.err.print("Per favore inserisci un numero > 0: ");
					scan.next(); // clear scanner wrong input
					continue; // continues to loop if exception is found
				}
			} catch (InputMismatchException e) { // if an exception appears prints message below
				System.err.print("Per favore non inserire lettere: ");
				scan.next(); // clear scanner wrong input
				continue; // continues to loop if exception is found
			}
			correctNumber = true;
		}
		return x;
	}

	/**
	 * METODO STATICO CHE CONTROLLA IL FORMAT DEL CODICE FISCALE INSERITO DALL'UTENTE:
	 */
	private static boolean checkCodFiscale(String cod) {
		int count = 0;
		boolean checkNumb = false;
		boolean checkLetter = false;
		String sostituto = cod;
		if (cod.length() == 16) {
			count = 16;
		}
		for (int i = 0; i < sostituto.trim().length() - 1; i++) {
			Character l = sostituto.trim().charAt(i);
			if (Character.isDigit(l)) {
				checkNumb = true;
			}
			if (Character.isLetter(l)) {
				checkLetter = true;
			}
		}
		if (count == 16) {
			/**
			 * controllo che il codice fiscale sia di 16 caratteri alfanumerici
			 */
			if (checkNumb == true) {
				if (checkLetter == true) {
					return true;
				} else {
					System.out.println("Hai inserito solo numeri. Reinserisci il codice fiscale correttamente. ");
					return false;
				}
			} else {
				System.out.println("Non hai inserito neanche un numero. Reinserisci il codice fiscale correttamente. ");
				return false;
			}
		} else {
			System.out.println(
					"Il codice fiscale inserito non ha lunghezza 16. Reinserisci il codice fiscale correttamente. ");
			return false;
		}
	}

	/**
	 * Metodo statico che restituisce false se la stringa nel parametro contiene numeri o è vuota
	 */
	private static boolean checkString(String n) {
		for (int i = 0; i <= n.length() - 1; i++) {
			Character l = n.trim().charAt(i);
			if (Character.isDigit(l)) {
				System.out.println("Hai inserito numeri! Reinserisci correttamente. ");
				return false;
			}
		}
		if (n.length() == 0) {
			System.out.println("Non hai inserito caratteri! Reinserisci correttamente. ");
			return false;
		}
		return true;
	}

	private static boolean checkVia(String y) {
		if (y.length() == 0) {
			System.out.print("Non hai inserito nulla, ripeti: ");
			return false;
		}
		for (int i = 0; i < y.length() - 1; i++) {
			Character c = y.trim().charAt(i);
			if (Character.isDigit(c) == true) {
				System.out.print("Non inserire numeri nella via, ripeti: ");
				return false;
			}
		}
		return true;
	}

	private static boolean checkEmail(String x) {
		boolean checkChiocciola = false;
		boolean checkPunto = false;
		char chiocciola = '@';
		char punto = '.';
		if (x.length() == 0) {
			System.out.println("Non hai inserito nulla. Ripeti: ");
			return false;
		}
		for (int i = 0; i < x.length(); i++) {
			Character c = x.trim().charAt(i);
			if (c.equals(chiocciola)) {
				checkChiocciola = true;
			}
		}
		if (checkChiocciola == true) {
			for (int j = 0; j < x.length(); j++) {
				Character d = x.trim().charAt(j);
				if (d.equals(punto)) {
					checkPunto = true;
				}
			}
			if (checkPunto == true) {
				return true;
			} else {
				System.out.print("Inserisci un indirizzo email corretto: ");
				return false;
			}
		} else {
			System.out.print("Inserisci un indirizzo email corretto: ");
			return false;
		}
	}

}
