/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import prog.io.ConsoleInputManager;

public class Playlist {

	/*
	 * //Campi public String TitoloPlaylist;
	 *
	 * /** Costruisce un oggetto playlist, che contiene il nome della playlist
	 *
	 * @param NomePlaylist nome della playlist da creare
	 */
	/*
	 * public Playlist(String NomePlaylist){ this.TitoloPlaylist = TitoloPlaylist; }
	 */

	/**
	 * Crea una nuova playlist, con i brani inseriti dall'utente
	 *
	 * @param in stream di input
	 */
	public void RegistraPlaylist(String NomePlaylist, ConsoleInputManager in) {
		in = new ConsoleInputManager();

		String titolo;
		String Autore;
		String Anno;
		boolean continua;

		CercaBrano c = new CercaBrano();

		LinkedList<String> ListaTitoli = new LinkedList<String>(); // contiene i titoli dei brani inseriti

		LinkedList<String> listRicercaBrani = new LinkedList<String>();

		do {

			System.out.println("Ricerca dei brani da inserire nella playlist");

			do {
				int n = 0;
				do {
					n = in.readInt(
							"Inserire 1 per eseguire la ricerca per titolo oppure 2 per la ricerca per autore + anno di pubblicazione: ");
				} while (!(n == 1) && !(n == 2));

				listRicercaBrani = CercaBrano.cercaBranoMusicale(n, in); // Cerca i brani nella repository

			} while (listRicercaBrani.isEmpty());

			String str = c.SceltaBrano(listRicercaBrani, in); // Scelta di un brano, tra quelli trovati
			ListaTitoli.add(str); // aggiunta nella lista (che contiene i brani da scrivere)

			continua = in.readSiNo("Vuoi inserire un'altro brano(s = Si, n = No)? ");

		} while (continua);

		String StringBrano = CreaStringaBraniAutori(ListaTitoli); // Creo la stringa che contiene tutti i brani + autori
																	// inseriti
		ScriviPlaylist(NomePlaylist, StringBrano); // Scrittura nel file "Playlist.dati.txt"

	}

	/**
	 * Restitusce una lista che contiene tutti i titolo + ";" + autori della
	 * playlist
	 *
	 * @param NomeDiPlaylist nome della playlist da cercare i brani
	 * @return lista che contiene ogni brano inserito
	 */
	public LinkedList<String> LetturaTitoloAutorePlaylist(String NomeDiPlaylist) {
		String s;
		String tuttiBraniAutore = " ";

		LinkedList<String> ListaBraniAutore = new LinkedList<String>(); // La lista che verra' restituita

		List<String> list = new LinkedList<String>();
		list = Utility.ReadFile("Playlist.dati.txt"); // Salvo una riga in ogni posizione della lista "list"

		for (int j = 0; j < list.size(); j = j + 1) {
			String str = list.get(j);
			int indice = str.indexOf("|");
			s = str.substring(0, indice).trim(); // Contiene il titolo della playlist A

			if (s.equals(NomeDiPlaylist.trim())) {
				tuttiBraniAutore = str.substring(indice + 1, str.length()); // +1 per non prendere la sbarra perche la
																			// posizione d'inizio e compresa

			}
		}

		if (tuttiBraniAutore.equals(" ")) {
			// non c'e' da fare nulla. Si restituisce semplicemente la ListaBraniAutore
			// vuota
		} else {

			// separo i brani in tuttiBraniAutore dagli spazzi
			StringTokenizer tokens = new StringTokenizer(tuttiBraniAutore, "|");
			while (tokens.hasMoreTokens()) {
				ListaBraniAutore.add(tokens.nextToken());

			}

		}

		return ListaBraniAutore;
	}

	/**
	 * Controlla se il titolo della playlist e' gia stato usato
	 *
	 * @param nome;
	 * @return true se e' il titolo e' gia' stato usato; false altrimenti
	 */
	public boolean checkNomePlaylist(String nome) {
		String s;
		boolean b = false;

		List<String> list = new LinkedList<String>();
		list = Utility.ReadFile("Playlist.dati.txt"); // Salvo una riga in ogni posizione della lista "list"

		for (int j = 0; j < list.size(); j = j + 1) {
			String str = list.get(j);
			s = str.substring(0, str.indexOf("|")).trim();

			if (s.equals(nome.trim())) {
				b = true;
			}
		}

		return b;
	}

	/**
	 * Stampa i nomi di tutte le playlist
	 */
	public static void ReadAllPlaylists() {
		List<String> list = new LinkedList<String>();
		list = Utility.ReadFile("Playlist.dati.txt"); // Salvo una riga in ogni posizione della lista "list"

		System.out.println("I nomi di tutti i playlist creati, che si trovano nella repository sono i seguenti: ");

		for (int j = 0; j < list.size(); j = j + 1) {

			String str = list.get(j);
			System.out.println(str.substring(0, str.indexOf("|")));

		}

	}

	// Controlla se il titolo del brano inserito (dall'utente) e' presente nella
	// repository "FiveHundredThousandSongs.txt"
	// Se e' presente restituisce true
	private boolean checkTitoloRepository(String t) {
		boolean b;

		LinkedList<String> list = new LinkedList<String>();

		list = CercaBrano.RicercaTitolo(t);
		if (list.isEmpty()) {
			b = false;
		} else {
			b = true;
		}

		// Cosi puo anche essere una parte del titolo e nn il titolo completto. Forse
		// l'utente deve poter selezionare una dei brani trovati
		return b;

	}

	// Metodo di scrittura sul file "Playlist.dati.txt"
	private static void ScriviPlaylist(String nomeP, String stringaBrani) {

		try {
			File file = new File("./../data/Playlist.dati.txt");
			Writer fw  = new OutputStreamWriter(new FileOutputStream(file.getAbsoluteFile().getAbsolutePath(), true), StandardCharsets.UTF_8);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(nomeP + "|" + stringaBrani + "\n");
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Crea il formato della stringa che contiene tutti i brani + autori da scrivere sul file
	private String CreaStringaBraniAutori(LinkedList<String> list) {
		String s = "";

		for (int i = 0; i < list.size(); i = i + 1) {

			s = s + list.get(i) + "|";
		}

		// int n = s.length() - 1;
		return s;// .substring(0, n); Perche mi serve l'ultima sbarra (|)
	}

}
