package emotionalsongs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class Utility {

	public static List<String> ReadFile(String nomeFile) {
		List<String> list = new LinkedList<String>();
		try {
			String pathFile = "./../data/" + nomeFile;
			File file = new File(pathFile);

			list = Files.readAllLines(file.getAbsoluteFile().toPath());

		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

}
