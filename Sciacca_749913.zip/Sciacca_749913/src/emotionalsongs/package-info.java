/** Contiene tutte le classi del progetto EmotionalSongs
 */
package emotionalsongs;
