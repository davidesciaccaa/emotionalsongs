/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Permette di effettuare il login controllando nome utente e password inseriti
 * dall'utente.
 */
public class Login {
	/**
	 * Questa variabile serve per memorizzare il nome utente inserito in input,
	 * viene confrontato con quelli memorizzati nel file UtentiRegistrati.txt
	 */
	public String nomeUtenteDaCercare;

	/**
	 * Questa variabile serve per memorizzare la password inserita in input, viene
	 * confrontato con quelli memorizzati nel file UtentiRegistrati.txt
	 */
	public String passwordDaCercare;

	/**
	 * Questa variabile serve per chiedere in input i dati per far loggare l'utente
	 */
	public Scanner scan = new Scanner(System.in);

	/**
	 * Questa variabile serve per verificare se il nome utente inserito per loggare
	 * esiste o no.
	 */
	public boolean nomeUt = false;

	/**
	 * Questa variabile serve per verificare se la password inserita per loggare
	 * esiste o no.
	 */
	public boolean psw = false;

	/**
	 * questa variabile diventa vera solo se nome utente e password inseriti per
	 * loggare coincidono con un utente gia' registrato nel file
	 * UtentiRegistrati.txt
	 */
	public static boolean finalCheck;

	/** Stampa il valore true se l'utente e' riuscito a loggare */
	public Login() {
		System.out.print("Ciao, per loggare inserisci innanzitutto il tuo nome utente: ");
		nomeUtenteDaCercare = scan.nextLine();
		while (nomeUtenteDaCercare.trim() == "") {
			System.out.println("Il nome utente inserito e' vuoto, riprova: ");
			nomeUtenteDaCercare = scan.nextLine();
		}
		System.out.print("Bene, ora inserisci la tua password: ");
		passwordDaCercare = scan.nextLine();
		while (!checkPassword(passwordDaCercare)) {
			passwordDaCercare = scan.nextLine();
		}

		/**
		 * conta gli account in UtentiRegistrati.txt, ogni riga corrisponde ad un
		 * account registrato.
		 */
		int cont = 0;

		/**
		 * memorizza nella variabile cont il numero di righe del file
		 * UtentiRegistrati.txt (quindi dice quanti utenti sono registrati)
		 */
		try {
			File file = new File("./../data/UtentiRegistrati.txt");
			FileReader read = new FileReader(file.getAbsoluteFile().getAbsolutePath());
			BufferedReader in = new BufferedReader(read);
			while (in.readLine() != null) {
				cont++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/** Controlla i dati del file UtentiRegistrati.txt */
		try {

			File file = new File("./../data/UtentiRegistrati.txt");
			BufferedReader reader = new BufferedReader(new FileReader(file.getAbsoluteFile().getAbsolutePath()));
			int i = 0;
			while (i < cont) {
				String currentLine = reader.readLine();
				String key;
				StringTokenizer st = new StringTokenizer(currentLine);

				if (st.hasMoreTokens()) {
					key = "" + st.nextToken("|");
					key = key.trim();
				}
				if (st.hasMoreTokens()) {
					key = "" + st.nextToken("|");
					key = key.trim();
					if (key.trim().equals(nomeUtenteDaCercare.trim())) {
						nomeUt = true;
					} else {
						nomeUt = false;
					}
				}
				if (st.hasMoreTokens()) {
					key = "" + st.nextToken("|");
					key = key.trim();
					if (key.trim().equals(passwordDaCercare.trim())) {
						psw = true;
					}
				}

				if (nomeUt == true && psw == true) {
					finalCheck = true;
				} else {
					nomeUt = false;
					psw = false;
				}

				i++; // per avanzare di riga, quindi per visitare un possibile account successivo
						// presente in UtentiRegistrati.txt
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (finalCheck) {
			System.out.println("Login eseguito con successo.");
		} else {
			System.out.println("Login non eseguito.");
		}
	}

	/**
	 * METODO STATICO CHE CONTROLLA IL FORMAT DELLA PASSWORD: DEVE AVERE ALMENO 8 CARATTERI E DEVE CONTENERE ALMENO UNA LETTERA E UN NUMERO.
	 */
	private static boolean checkPassword(String psw) {
		boolean checkPsw = false;
		boolean checkPswLettera = false;
		boolean checkPswNumero = false;
		if (psw.length() < 8) {
			System.out.println(
					"Hai inserito una password troppo corta, deve avere almeno 8 caratteri e contenere almeno una lettera e un numero. Riprova.");
			return false;
		} else {
			for (int i = 0; i < psw.length(); i++) {
				Character lettera = psw.trim().charAt(i);
				if (Character.isDigit(lettera)) {
					checkPswNumero = true;
				}
				if (Character.isLetter(lettera)) {
					checkPswLettera = true;
				}
			}
			if (checkPswNumero == false) {
				System.out.println("Non hai inserito nessun numero nella password. Riprova. ");
				return false;
			}
			if (checkPswLettera == false) {
				System.out.println("Non hai inserito nessuna lettera nella password. Riprova. ");
				return false;
			} else {
				return true;
			}
		}
	}

	/**
	 * mi serve per poter dire nel main EmotionalSongs se l'utente ha loggato o meno.
	 */
	public static boolean returnVal() {
		return finalCheck;
	}

}
