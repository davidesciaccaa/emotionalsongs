/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import prog.io.ConsoleInputManager;

public class CercaBrano {

	// Costruttore vuoto
	// Serve per il metodo NONstatico
	public CercaBrano() {
	};

	/**
	 * ricerca per titolo del brano, sulla repository di canzoni inserite
	 *
	 * @param TitoloInserito titolo del brano da cercare
	 * @return lista che contiene le righe del file della repository che contengono
	 *         il brano cercato
	 * @version Java 18
	 */
	public static LinkedList<String> RicercaTitolo(String TitoloInserito) {

		List<String> list = new LinkedList<String>(); // perche' list e' una interfaccia
		LinkedList<String> list2 = new LinkedList<String>();

		list = Utility.ReadFile("FiveHundredThousandSongs.txt");

		// Version token:
		LinkedList<String> TitoloSPLIT = new LinkedList<String>();

		StringTokenizer tokens = new StringTokenizer(TitoloInserito.toLowerCase(), " ");
		while (tokens.hasMoreTokens()) {
			TitoloSPLIT.add(tokens.nextToken());

		}

		for (int i = 0; i < list.size(); i++) {
			String v = list.get(i).toLowerCase();
			int n = v.indexOf(">", 33);
			String s = v.substring(n + 1).trim(); // da qua fino alla fine, quindi prende solo il titolo

			boolean trovato = false;

			for (int j = 0; j < TitoloSPLIT.size(); j = j + 1) {
				String h = TitoloSPLIT.get(j);

				if (s.contains(h)) {
					// apo equals + ndaje dhe titullin dalle righe??? cosi evita di restituire cose
					// per esempio inserendo 1 solo carattere
					trovato = true;
				} else {
					// se ce almeno 1 false(cioe una parola non contenuta nel titolo) la riga non
					// viene presa
					trovato = false;
					break;
				}

			}

			if (trovato) {
				list2.add(v);

			}
		}

		return list2;
	}

	/**
	 * ricerca per anno e autore del brano, sulla repository di canzoni inserite
	 *
	 * @param Anno anno di pubblicazione del brano da cercare
	 * @param Autore autore del brano da cercare
	 * @return lista che contiene le righe del file della repository che contengono
	 *         il brano cercato
	 */
	public static LinkedList<String> RicercaAutoreAnno(int Anno, String Autore) {

		List<String> list = new LinkedList<String>();
		LinkedList<String> listaAnno = new LinkedList<String>();
		LinkedList<String> listaFinale = new LinkedList<String>();
		String AnnoString = String.valueOf(Anno);

		list = Utility.ReadFile("FiveHundredThousandSongs.txt");

		// Prima salvo sulla listaAnno le righe che contengono AnnoString
		for (int i = 0; i < list.size(); i = i + 1) {

			String s = list.get(i);
			String v = s.substring(0, 4); // 4 e' escluso

			if (v.equals(AnnoString)) {
				listaAnno.add(s);

			}

		}

		// Divido nome e cognome del'autore dai spazi per confrontarli anche in ordine diverso
		String[] AutoreSPLIT = new String[6];
		AutoreSPLIT = Autore.toLowerCase().trim().split(" ");

		// Dalle righe gia selezionate dall'anno, che si trovano sulla listaAnno scelgo quelle che contengono l'autore
		for (int i = 0; i < listaAnno.size(); i = i + 1) {

			String a = listaAnno.get(i).toLowerCase();
			String autoreRep = a.substring(32, a.indexOf("<", 32)); // contiene il nome dell'autore, dalla riga
																	// selezionata
			boolean bool = false;

			for (int j = 0; j < AutoreSPLIT.length; j = j + 1) {
				// Controllo ogni volta se uno delle parole che costituiscono il
				// nome dell'autore e presente nel nome dell'autore nella repository
				String h = AutoreSPLIT[j];
				if (autoreRep.contains(h)) {
					bool = true;
				} else {
					bool = false;
					break; // cosi non restituisce anche 2 titoli che sono complettamente identiche
				}
			}
			if (bool == true) {
				listaFinale.add(a);
			}

		}

		return listaFinale;

	}

	/**
	 * Stampa e permette di effettuare un scelta tra tutti i brani cercati
	 *
	 * @param listaB lista che contiene i brani trovati dalla ricerca
	 * @param in     costruzione dello stream di input
	 * @return restituisce una stringa che contiene i dati del brano selezionato
	 */
	public String SceltaBrano(LinkedList<String> listaB, ConsoleInputManager in) {
		System.out.println();
		in = new ConsoleInputManager();
		String str;
		LinkedList<String> ListaBSelezionati = new LinkedList<String>();

		// Stampa tutti i brani trovati
		for (int i = 0; i < listaB.size(); i = i + 1) {
			String riga = listaB.get(i);
			String titolo = riga.substring(riga.lastIndexOf(">") + 1).toUpperCase().trim();
			String autore = riga.substring(32, riga.indexOf("<", 32)).toUpperCase().trim();

			str = titolo + ";" + autore;

			ListaBSelezionati.add(str);
			// System.out.println(i + ")" + "Titolo: " + titolo + "; " + "Autore: " +
			// autore);
		}

		RimuoviDuplicati(ListaBSelezionati);

		for (int i = 0; i < ListaBSelezionati.size(); i = i + 1) {
			String k = ListaBSelezionati.get(i);
			int l = k.indexOf(";");
			String t = k.substring(0, l);
			String a = k.substring(l + 1);
			System.out.println(i + ") " + "Titolo: " + t + ";" + "Autore: " + a);
		}

		// Selezione
		int selezionato;
		String s = " ";
		if (ListaBSelezionati.isEmpty()) {
			System.out.println("Nessun brano trovato.");
			System.out.println();
		} else {

			do {
				selezionato = in.readInt(
						"Selezionare un brano (bisogna inserire solo il numero trovato all'inizio di ogni riga stampata): ");
			} while (selezionato < 0 || selezionato >= ListaBSelezionati.size());

			for (int i = 0; i < ListaBSelezionati.size(); i = i + 1) {
				s = ListaBSelezionati.get(selezionato);
			}

		}

		return s;

	}

	private void RimuoviDuplicati(LinkedList<String> lista) {

		Set<String> set = new HashSet<>(lista);
		lista.clear();
		lista.addAll(set);

	}

	/**
	 * Permette di selezionare il tipo della ricerca del brano
	 *
	 * @param n  1 = ricerca per titolo; 2= ricerca autore + anno
	 * @param in stream di input
	 * @return una lista che contiene i brani trovati
	 */
	public static LinkedList<String> cercaBranoMusicale(int n, ConsoleInputManager in) {
		in = new ConsoleInputManager();
		LinkedList<String> list = new LinkedList<String>();
		switch (n) {
		case 1:
			String titolo = in.readLine("Inserire il titolo del brano da cercare: ");
			list = CercaBrano.RicercaTitolo(titolo);
			break;
		case 2:
			String Autore = in.readLine("Inserire l'autore del brano da cercare: ");
			int Anno = in.readInt("Inserire l'anno di pubblicazione del brano da cercare: ");
			list = CercaBrano.RicercaAutoreAnno(Anno, Autore);
			break;
		}

		return list;
	}

}
