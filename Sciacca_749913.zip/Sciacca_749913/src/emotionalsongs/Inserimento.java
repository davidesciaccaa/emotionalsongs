/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import prog.io.ConsoleInputManager;

public class Inserimento {

	// Campi
	public String Titolo;
	public String Autore;

	// costruttore che crea un oggetto
	public Inserimento(String Titolo, String Autore) {
		this.Titolo = Titolo;
		this.Autore = Autore;
	}

	// Metodo 1
	// Si presuppone che l'utente ha gia' selezionato un brano dopo la ricerca

	/**
	 * permette di inserire le emozioni provate dall'ascolto di un brano
	 *
	 * @param in stream di input
	 */
	public void InserisciEmozioniBrano(ConsoleInputManager in) {
		in = new ConsoleInputManager();

		String E;
		String nota = " ";
		char score;

		LinkedList<String> ListaE = new LinkedList<String>();
		LinkedList<Character> ListaScore = new LinkedList<Character>();

		System.out.println("Le emozioni che si possono inserire sono le seguenti:");
		System.out.println("Amazement (Codice: A)");
		System.out.println("Solemnity (Codice: B)");
		System.out.println("Tenderness (Codice: C)");
		System.out.println("Nostalgia (Codice: D)");
		System.out.println("Calmness (Codice: E)");
		System.out.println("Power (Codice: F)");
		System.out.println("Joy (Codice: G)");
		System.out.println("Tension (Codice: H)");
		System.out.println("Sadness (Codice: I)");
		System.out.println("ATTENZIONE! Bisogna inserire solo il codice associato alla emozione.");

		do {
			E = in.readLine(
					"Inserisci il codice della emozione che hai sentito quando hai ascoltato la canzone inserita: ");
		} while (checkEmozione(E.toUpperCase()) == false);
		ListaE.add(E);

		do {
			score = in.readChar("Inserisci lo score(Un numero intero da 1 a 5): ");
		} while (checkScore(score) == false);
		ListaScore.add(score);

		String EmozioniScore = CreaEmozioneScore(ListaE, ListaScore);

		boolean b = in.readSiNo("Vuoi inserire una nota(s = Si, n = No)? ");

		if (b == true) {
			nota = in.readLine("Inserire la nota: ");
			System.out.println("Nota inserita");
		}
		System.out.println();
		ScriviEmozione(this.Titolo, this.Autore, EmozioniScore, nota);
	}

	private boolean checkEmozione(String s) {
		boolean b;
		if (s.equals("A") || s.equals("B") || s.equals("C") || s.equals("D") || s.equals("E") || s.equals("F")
				|| s.equals("G") || s.equals("H") || s.equals("I")) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}

	private boolean checkScore(char c) {
		boolean b;
		if (c == '1' || c == '2' || c == '3' || c == '4' || c == '5') {
			b = true;
		} else
			b = false;

		return b;
	}

	private static void ScriviEmozione(String titolo, String autore, String emozioneScore, String nota) {

		try {

			File file = new File("./../data/Emozioni.dati.txt");

			Writer fw  = new OutputStreamWriter(new FileOutputStream(file.getAbsoluteFile().getAbsolutePath(), true), StandardCharsets.UTF_8);

			BufferedWriter bw = new BufferedWriter(fw);

			bw.write(titolo + ";" + autore + "|" + emozioneScore + "|" + nota + "\n");


			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private String CreaEmozioneScore(LinkedList<String> ListaEmozioni, LinkedList<Character> ListaScore) {
		String s = "";

		for (int i = 0; i < ListaEmozioni.size(); i = i + 1) {
			String score = Character.toString(ListaScore.get(i));
			s = s + ListaEmozioni.get(i) + score + ";";
		}

		int n = s.length() - 1;
		return s.substring(0, n);
	}

}
