/**@author Davide Sciacca, matricola nr. 749913, sede VARESE - Ylli braci, matricola nr. 749714, sede VARESE*/

package emotionalsongs;

import java.util.LinkedList;
import java.util.List;

public class Visualizza {

	public String NomeFile;

	/**
	 * costruisce un oggetto che contiene il nome del file
	 *
	 * @param NomeFile il nome del file dal quale si visualizzerano i dati
	 */
	public Visualizza(String NomeFile) { // costruisce un oggetto Visualizza, che contiene il nome del file
											// Emozioni.dati
		this.NomeFile = NomeFile;
	}

	/**
	 * stampa le informazioni inserite dagli utenti per il brano in input
	 *
	 * @param Titolo titolo brano
	 * @param Autore autore brano
	 * @version Java 18
	 */
	public void visualizzaEmozioneBrano(String Titolo, String Autore) {

		List<String> list = new LinkedList<String>();
		LinkedList<String> list2 = new LinkedList<String>();
		LinkedList<String> listEmozioni = new LinkedList<String>();
		LinkedList<String> listNote = new LinkedList<String>();

		list = Utility.ReadFile(this.NomeFile);

		String s = Titolo + ";" + Autore;
		String k = s.toLowerCase();

		for (int i = 0; i < list.size(); i = i + 1) {

			String v = list.get(i).toLowerCase();

			if (v.contains(k)) {
				list2.add(v);

			}

		}

		if (list2.isEmpty() == true) {

			System.out.println("Non e' stata inserita nessuna emozione");

		} else {

			for (int i = 0; i < list2.size(); i = i + 1) {

				String stringa = list2.get(i);
				int inizioEmozioni = stringa.indexOf("|") + 1; // senza +1 il primo conterra anche |
				int inizioNote = stringa.lastIndexOf("|");

				String Emozioni = stringa.substring(inizioEmozioni, inizioNote);

				String[] EmozioniSPLIT = new String[9];
				EmozioniSPLIT = Emozioni.split(";");

				for (int j = 0; j < EmozioniSPLIT.length; j = j + 1) {

					listEmozioni.add(EmozioniSPLIT[j]); // Contiene tutte le emozioni es A5, B2...

				}

				String Note = stringa.substring(inizioNote + 1);
				listNote.add(Note.toUpperCase()); // Contiene tutte le note inserite per questo brano. Puo essere anche
													// vuota
			}

			int countA = 0;
			char ScoreA = 0;

			int countB = 0;
			char ScoreB = 0;

			int countC = 0;
			char ScoreC = 0;

			int countD = 0;
			char ScoreD = 0;

			int countE = 0;
			char ScoreE = 0;

			int countF = 0;
			char ScoreF = 0;

			int countG = 0;
			char ScoreG = 0;

			int countH = 0;
			char ScoreH = 0;

			int countI = 0;
			char ScoreI = 0;

			for (int i = 0; i < listEmozioni.size(); i++) {
				String str = listEmozioni.get(i);
				char codiceEmozione = str.charAt(0);
				char scoreInserito = str.charAt(1);
				if (codiceEmozione == 'a') {
					countA = countA + 1;
					ScoreA = (char) (ScoreA + scoreInserito); // oppure li puoi convertire in interi
				} else {
					if (codiceEmozione == 'b') {
						countB = countB + 1;
						ScoreB = (char) (ScoreB + scoreInserito); // oppure li puoi convertire in interi
					} else {
						if (codiceEmozione == 'c') {
							countC = countC + 1;
							ScoreC = (char) (ScoreC + scoreInserito); // oppure li puoi convertire in interi
						} else {
							if (codiceEmozione == 'd') {
								countD = countD + 1;
								ScoreD = (char) (ScoreD + scoreInserito); // oppure li puoi convertire in interi
							} else {
								if (codiceEmozione == 'e') {
									countE = countE + 1;
									ScoreE = (char) (ScoreE + scoreInserito); // oppure li puoi convertire in interi
								} else {
									if (codiceEmozione == 'f') {
										countF = countF + 1;
										ScoreF = (char) (ScoreF + scoreInserito); // oppure li puoi convertire in interi
									} else {
										if (codiceEmozione == 'g') {
											countG = countG + 1;
											ScoreG = (char) (ScoreG + scoreInserito); // oppure li puoi convertire in
																						// interi
										} else {
											if (codiceEmozione == 'h') {
												countH = countH + 1;
												ScoreH = (char) (ScoreH + scoreInserito); // oppure li puoi convertire
																							// in interi
											} else {
												if (codiceEmozione == 'i') {
													countI = countI + 1;
													ScoreI = (char) (ScoreI + scoreInserito); // oppure li puoi
																								// convertire in interi
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			char mediaA = 0;
			char mediaB = 0;
			char mediaC = 0;
			char mediaD = 0;
			char mediaE = 0;
			char mediaF = 0;
			char mediaG = 0;
			char mediaH = 0;
			char mediaI = 0;

			if (countA != 0) {
				System.out.println(countA + " utenti hanno inserito: Amazement.");
				mediaA = (char) (ScoreA / countA);
				System.out.println("Score medio: " + mediaA);
				System.out.println(); // riga vuota
			}

			if (countB != 0) {
				System.out.println(countB + " utenti hanno inserito: Solemnity.");
				mediaB = (char) (ScoreB / countB);
				System.out.println("Score medio: " + mediaB);
				System.out.println();
			}

			if (countC != 0) {
				System.out.println(countC + " utenti hanno inserito: Tenderness.");
				mediaC = (char) (ScoreC / countC);
				System.out.println("Score medio: " + mediaC);
				System.out.println();
			}

			if (countD != 0) {
				System.out.println(countD + " utenti hanno inserito: Nostalgia.");
				mediaD = (char) (ScoreD / countD);
				System.out.println("Score medio: " + mediaD);
				System.out.println();
			}

			if (countE != 0) {
				System.out.println(countE + " utenti hanno inserito: Calmness.");
				mediaE = (char) (ScoreE / countE);
				System.out.println("Score medio: " + mediaE);
				System.out.println();
			}

			if (countF != 0) {
				System.out.println(countF + " utenti hanno inserito: Power.");
				mediaF = (char) (ScoreF / countF);
				System.out.println("Score medio: " + mediaF);
				System.out.println();
			}

			if (countG != 0) {
				System.out.println(countG + " utenti hanno inserito: Joy.");
				mediaG = (char) (ScoreG / countG);
				System.out.println("Score medio: " + mediaG);
				System.out.println();
			}

			if (countH != 0) {
				System.out.println(countH + " utenti hanno inserito: Tension.");
				mediaH = (char) (ScoreH / countH);
				System.out.println("Score medio: " + mediaH);
				System.out.println();
			}

			if (countI != 0) {
				System.out.println(countI + " utenti hanno inserito: Sadness.");
				mediaI = (char) (ScoreI / countI);
				System.out.println("Score medio: " + mediaI);
				System.out.println();
			}

			if (listNote.isEmpty() == false) {
				int lunghezza;
				if (listNote.size() < 15) {
					lunghezza = listNote.size();
				} else {
					lunghezza = 14;
				}
				System.out.println("Alcune note inserite:");
				for (int j = 0; j < lunghezza; j = j + 1) {

					System.out.println(listNote.get(j));
					System.out.println();
				}
			}
		}

	}

}
